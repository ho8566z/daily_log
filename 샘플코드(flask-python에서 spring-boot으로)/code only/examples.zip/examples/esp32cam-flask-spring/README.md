# ESP32-CAM → Flask → Spring 샘플

Flask 스트림 서버가 프레임 처리 후 만든 이미지와 결과 데이터를 Spring Boot 서버로 전달하는 예제입니다. ESP32-CAM에서 Flask로 프레임을 보내는 부분은 기존 구현을 그대로 사용하고, Flask가 최종 이미지와 분석 결과를 얻은 시점에 전달 함수를 호출합니다.

## 전송 흐름

1. ESP32-CAM이 기존 방식대로 Flask 스트림 서버에 프레임을 전달합니다.
2. Flask가 프레임을 처리해 JPEG 바이트와 결과 딕셔너리를 만듭니다.
3. Flask가 `POST /api/camera/frames`로 `multipart/form-data` 요청을 보냅니다.
   - `image`: JPEG 파일
   - `metadata`: JSON 파트
4. Spring이 JSON을 파싱하고 이미지를 `uploads/`에 저장한 뒤 접수 결과를 반환합니다.

## 구성

- `flask-forwarder/`: 기존 Flask 코드에서 가져다 쓸 전달 함수
- `spring-receiver/`: multipart 요청을 받는 Spring Boot 서버

## 실행 방법

### 1. Spring 수신 서버 실행

Java 17 이상과 Maven이 필요합니다.

```bash
cd examples/esp32cam-flask-spring/spring-receiver
mvn spring-boot:run
```

기본 주소는 `http://localhost:8080`이며, 수신한 이미지는 `uploads/`에 저장됩니다.

### 2. Flask 전달 코드 준비

기존 Flask 가상환경에 아래 패키지를 설치합니다.

```bash
pip install -r examples/esp32cam-flask-spring/flask-forwarder/requirements.txt
```

Spring이 Flask와 다른 컴퓨터에서 실행 중이면 Spring 컴퓨터의 주소를 지정합니다. `localhost`는 Flask가 실행되는 컴퓨터 자신을 가리킵니다.

```bash
export SPRING_RECEIVER_URL=http://192.168.0.20:8080/api/camera/frames
```

Windows PowerShell:

```powershell
$env:SPRING_RECEIVER_URL = "http://192.168.0.20:8080/api/camera/frames"
```

기존 Flask 처리 코드에서 JPEG 바이트와 산출 데이터가 준비된 직후 다음처럼 호출합니다.

```python
from spring_forwarder import forward_result_to_spring

# frame_jpeg: 처리 결과 이미지의 JPEG bytes
# result_data: Flask가 산출한 dict
receipt = forward_result_to_spring(
    image_bytes=frame_jpeg,
    metadata={
        "deviceId": "esp32-cam-01",
        "capturedAt": "2026-09-30T12:00:00Z",
        **result_data,
    },
)
```

OpenCV 프레임 배열만 있다면 전송 전에 JPEG bytes로 변환합니다.

```python
ok, encoded = cv2.imencode(".jpg", frame)
if not ok:
    raise RuntimeError("JPEG 인코딩 실패")
frame_jpeg = encoded.tobytes()
```

`spring_forwarder.py`의 기본 주소는 `http://localhost:8080/api/camera/frames`입니다. Flask와 Spring이 다른 호스트에서 실행되면 `SPRING_RECEIVER_URL`을 Spring 호스트에 맞게 설정해야 합니다.

## 요청 예시

Spring 서버가 실행 중일 때 이미지 한 장을 직접 전송해 볼 수 있습니다.

```bash
curl -X POST http://localhost:8080/api/camera/frames \
  -F 'image=@frame.jpg;type=image/jpeg' \
  -F 'metadata={"deviceId":"esp32-cam-01","capturedAt":"2026-09-30T12:00:00Z","temperatureC":24.6,"detection":{"label":"person","confidence":0.96}};type=application/json'
```

성공 응답 예시:

```json
{
  "frameId": "c91d...",
  "storedAs": "c91d....jpg",
  "receivedAt": "2026-09-30T12:00:01.123Z"
}
```

## 참고

- `metadata`의 키는 예시이므로 Flask가 실제로 산출하는 데이터 구조에 맞게 바꾸면 됩니다.
- 스트림 프레임마다 Spring 호출을 동기적으로 수행하면 스트림 처리 속도가 느려질 수 있습니다. 먼저 결과 저장이 필요한 프레임에만 호출하고, 고속 전송이 필요하면 별도 큐/작업자 방식으로 분리하세요.
- 이 샘플은 로컬 네트워크 개발용이며 인증을 포함하지 않습니다. 인터넷에 공개하기 전에는 HTTPS와 서비스 간 인증을 추가하세요.