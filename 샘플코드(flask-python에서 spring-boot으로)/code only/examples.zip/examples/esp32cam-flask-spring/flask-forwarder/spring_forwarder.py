"""Send a Flask-produced JPEG and its metadata to the Spring receiver."""

import json
import os
from typing import Any

import requests


SPRING_RECEIVER_URL = os.getenv(
    "SPRING_RECEIVER_URL",
    "http://localhost:8080/api/camera/frames",
)
REQUEST_TIMEOUT_SECONDS = float(os.getenv("SPRING_REQUEST_TIMEOUT_SECONDS", "10"))


def forward_result_to_spring(
    image_bytes: bytes,
    metadata: dict[str, Any],
    *,
    receiver_url: str = SPRING_RECEIVER_URL,
) -> dict[str, Any]:
    """POST one JPEG image and a JSON metadata object; raise on delivery failure."""
    if not image_bytes:
        raise ValueError("image_bytes must not be empty")

    metadata_json = json.dumps(metadata, ensure_ascii=False)
    response = requests.post(
        receiver_url,
        files={
            "image": ("frame.jpg", image_bytes, "image/jpeg"),
            "metadata": (None, metadata_json, "application/json"),
        },
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    return response.json()