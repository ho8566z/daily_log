package example.receiver;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/camera")
public class FrameController {
    private static final Set<String> ACCEPTED_IMAGE_TYPES = Set.of(
        MediaType.IMAGE_JPEG_VALUE,
        MediaType.IMAGE_PNG_VALUE
    );

    private final Path storageDirectory;

    public FrameController(@Value("${app.storage-dir:./uploads}") String storageDirectory) {
        this.storageDirectory = Path.of(storageDirectory).toAbsolutePath().normalize();
    }

    @PostMapping(
        path = "/frames",
        consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<FrameReceipt> receiveFrame(
        @RequestPart("image") MultipartFile image,
        @RequestPart("metadata") Map<String, Object> metadata
    ) throws IOException {
        if (image.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "image is required");
        }
        if (metadata == null || metadata.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "metadata JSON is required");
        }

        String contentType = image.getContentType();
        if (contentType == null || !ACCEPTED_IMAGE_TYPES.contains(contentType)) {
            throw new ResponseStatusException(
                HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                "Only JPEG and PNG images are accepted"
            );
        }

        String extension = MediaType.IMAGE_PNG_VALUE.equals(contentType) ? ".png" : ".jpg";
        String frameId = UUID.randomUUID().toString();
        String storedAs = frameId + extension;

        Files.createDirectories(storageDirectory);
        Path destination = storageDirectory.resolve(storedAs).normalize();
        if (!destination.getParent().equals(storageDirectory)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid image path");
        }
        image.transferTo(destination);

        return ResponseEntity.status(HttpStatus.CREATED)
            .body(new FrameReceipt(frameId, storedAs, Instant.now()));
    }

    public record FrameReceipt(String frameId, String storedAs, Instant receivedAt) {}
}